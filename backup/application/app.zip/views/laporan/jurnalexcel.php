<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=jurnal_".$date.".xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
				<table width="100%" border="0">
					<tr>
						<th scope="col" style="width:30px">No</th>
						<th scope="col" style="text-align:center;">Tgl Transaksi</th>
						<th scope="col" style="text-align:center;">Keterangan</th>
						<th scope="col" style="text-align:center;">Nama Siswa (Kelas)</th>
						<th scope="col" style="text-align:right;">Jumlah</th>
						<th scope="col" style="text-align:center;">Status</th>
					</tr>
					<?
					$total=0;
					for($i=0;$i<count($tr);$i++)
					{
						if($tr[$i]->keterangan==0)
							$jen=$tr[$i]->jenis.' '.$tr[$i]->thn;
						else
							$jen=$tr[$i]->jenis.' Bulan : '.getBulan($tr[$i]->keterangan).' '.$tr[$i]->thn;


						echo '<tr>
							<td style="text-align:center">'.($i+1).'</td>
							<td style="text-align:center">'.tgl_indo($tr[$i]->tgl_transaksi).'</td>
							<td style="text-align:left">Penerimaan '.$tr[$i]->jenis.' '.$jen.'</td>
							<td style="text-align:left">'.$tr[$i]->nama."--".' Kelas : '.$tr[$i]->t_kelas_id.'</td>
							<td style="text-align:right">'.((float)($tr[$i]->jumlah)).'</td>
							<td style="text-align:center">'.($tr[$i]->status_pembayaran).'</td>
						</tr>';
						$total+=$tr[$i]->jumlah;
					}
					?>
					<tr>
						<th scope="col" colspan="4" style="text-align:right">Total</th>
						<th scope="col" style="text-align:right;"><?=((float)($total))?></th>
						<th scope="col" style="text-align:right;"></th>
	
					</tr>
				</table>