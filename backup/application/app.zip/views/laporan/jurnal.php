	<div>
		<ul class="breadcrumb">
			<li>
				<a href="<?=base_url()?>">Home</a> <span class="divider">/</span>
			</li>
			<li>
				<a href="#">Jurnal Harian</a>
			</li>
		</ul>
		<div class="row-fluid sortable ui-sortable">		
				<div class="box span12">
					<div class="box-header well" data-original-title="">
						<h2><i class="icon-user"></i> Jurnal</h2>
						<div class="box-icon">
						</div>
					</div>

					<div class="box-content" style="background:#fff">
						<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
							<a data-rel="tooltip" class="well span3 top-block" href="<?=site_url()?>laporan/datajurnal/harian" data-original-title="Data Per Kelas">
								<span class="icon32 icon-color icon-book"></span>
								<div>Jurnal Harian</div>
								
								
							</a>
							<a data-rel="tooltip" class="well span3 top-block" href="<?=site_url()?>laporan/datajurnal/bulanan" data-original-title="Data Per Siswa">
								<span class="icon32 icon-color icon-book-empty"></span>
								<div>Jurnal Bulanan</div>
								
								
							</a>
						</div>
					</div>
				</div>
			</div>
