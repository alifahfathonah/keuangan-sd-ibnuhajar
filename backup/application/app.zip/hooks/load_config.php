<?php
/*	CREATE TABLE `db_sd_ibnuhajar`.`t_pembagian` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '',
  `nama_kelas` VARCHAR(255) NULL COMMENT '',
  `tahun_ajaran` VARCHAR(45) NULL COMMENT '',
  `status` ENUM('t', 'f', 'i') NULL DEFAULT 't' COMMENT '',
  `walikelas` VARCHAR(255) NULL COMMENT '',
  PRIMARY KEY (`id`)  COMMENT '');
*/
//Loads configuration from database into global CI config
function load_config()
{
	$ci =& get_instance();

	$t_pembagian=$ci->db->query('show tables like "t_pembagian"');
	if($t_pembagian->num_rows==0)
	{
		$ci->db->query("CREATE TABLE `t_pembagian` (
						  `id` INT NOT NULL AUTO_INCREMENT COMMENT '',
						  `nama_kelas` VARCHAR(255) NULL COMMENT '',
						  `tahun_ajaran` VARCHAR(45) NULL COMMENT '',
						  `status` ENUM('t', 'f', 'i') NULL DEFAULT 't' COMMENT '',
						  `walikelas` VARCHAR(255) NULL COMMENT '',
						  PRIMARY KEY (`id`)  COMMENT '');");
	}

	$t_pembagian_data=$ci->db->query('show tables like "t_pembagian_siswa"');
	if($t_pembagian_data->num_rows==0)
	{
		$ci->db->query("CREATE TABLE `t_pembagian_siswa` (
						  `id` INT NOT NULL AUTO_INCREMENT COMMENT '',
						  `id_pembagian` INT NULL COMMENT '',
						  `nama_siswa` VARCHAR(255) NULL COMMENT '',
						  `id_siswa` VARCHAR(255) NULL COMMENT '',
						  `id_kelas_aktif` BIGINT NULL COMMENT '',
						  `status` ENUM('t', 'f') NULL COMMENT '',
						  PRIMARY KEY (`id`));");
	}
}
?>