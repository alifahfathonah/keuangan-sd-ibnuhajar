<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include_once('a.php');
class Config extends A {

	function __construct()
	{
		parent::__construct();

		if($this->session->userdata('sistem')=='SD')
		{
			$this->load->database('default',true);
		}
		else
		{
			$this->db=$this->load->database('second',true);
		}
		
		if($this->session->userdata('logged')!='TRUE')
			redirect('login','location');
	}
	
	function tahunajaran()
	{
		$data['title']='Pengaturan Tahun Ajaran';
		$data['isi']='config/tahunajaran';
		$data['data']=$this->cm->getTahunAjaran(-1)->result();
		$this->load->view('index',$data);
	}
	function addajaran()
	{
		if(!empty($_POST))
		{
			$ta=$this->input->post('tahunajaran');
			$this->cm->saveTahunAjaran($ta);
			
			redirect('config/tahunajaran','location');
		}
	}

	function editajaran($id)
	{
		$data['det']=$det=$this->cm->getTahunAjaran($id);
		$data['id']=$id;
		if(!empty($_POST))
		{
			$data['ta']=$this->input->post('tahunajaranedit');
			$this->cm->EditTahunAjaran($data);
			
			redirect('config/tahunajaran','location');
		}

		echo '<form id="fform-action-edit" style="width:100% !important" class="form-horizontal" action="'.site_url().'config/editajaran/'.$id.'" method="post" enctype="multipart/form-data">
				<div class="">

					<div class="control-group">
					  <label class="control-label" for="typeahead">Tahun Ajaran</label>
					  <div class="controls">
						<input type="text" name="tahunajaranedit" class="span6 typeahead" id="tahunajaran" value="'.$det->row('tahunajaran').'" style="width:80%;">
					  </div>
					</div>
		
					
				</div>
			</form>	';
	}

	///////////////////////Driver/////////////////////////////

	function driver()
	{
		$data['title']='Pengaturan Data Driver';
		$data['isi']='config/driver';
		$data['data']=$this->cm->getDriver(-1)->result();
		$this->load->view('index',$data);
	}

	function tambahdriver()
	{
		if(!empty($_POST))
		{
			$data['id']=abs(crc32(md5(rand())));
			$data['nama']=$this->input->post('nama');
			$data['alamat']=$this->input->post('alamat');
			$data['telp']=$this->input->post('telp');
			$this->cm->saveDriver($data);
			redirect('config/driver','location');
		}
	}

	function editdriver($id)
	{
		$data['det']=$det=$this->cm->getDriver($id);
		$data['id']=$id;
		if(!empty($_POST))
		{
			$data['nama']=$this->input->post('nama');
			$data['alamat']=$this->input->post('alamat');
			$data['telp']=$this->input->post('telp');
			$data['id']=$id;
			$this->cm->updateDriver($data);
			
			redirect('config/driver','location');
		}

		echo '<form id="fform-action-edit" style="width:100% !important" class="form-horizontal" action="'.site_url().'config/editdriver/'.$id.'" method="post" enctype="multipart/form-data">
	<div class="">
		<div class="control-group">
		  <label class="control-label" for="typeahead">Nama</label>
		  <div class="controls">
			<input type="text" name="nama" value="'.$det->row('nama_driver').'" class="span6 typeahead" id="" style="width:80%;">
		  </div>
		</div>
		<div class="control-group">
		  <label class="control-label" for="typeahead">Rute</label>
		  <div class="controls">
			<input type="text" name="alamat" value="'.$det->row('alamat').'" class="span6 typeahead" id="" style="width:80%;">
		  </div>
		</div>
		<div class="control-group">
		  <label class="control-label" for="typeahead">Telp</label>
		  <div class="controls">
			<input type="text" name="telp" class="span6 value="'.$det->row('telp').'" typeahead" id="" style="width:80%;">
		  </div>
		</div>		
		 
	</div>
</form>';
	}

	function adddriversiswa($idjenis)
	{
		if(!empty($_POST))
		{
			$data['iddriver']=$iddriver=$this->input->post('iddriver');
			$nis=$this->input->post('namasiswa');

			foreach ($nis as $k => $n) 
			{
				# code...
				$data['nis']=$n;
				if(!empty($n) || $n!='')
				{
					$this->cm->saveDriverSiswa($data);
				}
			}
			//echo $iddriver.'-'.$nis;
			
			redirect('penerimaan/rutin/'.$idjenis.'','location');
		}
	}

	function editspp()
	{
		$sq=$this->db->query('select * from v_data_kewajiban where sisa=0 and (t_jenis_pembayaran_id=3 or t_jenis_pembayaran_id=4)');
		if($sq->num_rows!=0)
		{
			foreach ($sq->result() as $k => $v) 
			{
				$cek=$this->db->query('select * from t_penerimaan_rutin where t_siswa_nis="'.$v->t_siswa_nis.'" and t_siswa_has_t_kelas_id="'.$v->t_kelas_aktif_id.'" and t_jenis_pembayaran_id="10" and bulan=7');
				// $this->db->query("update t_penerimaan_rutin set sudah_bayar='300000', sisa_bayar=0 where id='".$cek->row('id')."'");
				
				$pemb=$this->db->query('select * from t_pembayaran where t_jenis_pembayaran_id=4 and t_siswa_has_t_kelas_id="'.$v->t_kelas_aktif_id.'"');

				if($pemb->num_rows!=0)
				{
					$ins=array(
						't_jenis_pembayaran_id'=>10,
						't_siswa_has_t_kelas_id'=>$v->t_kelas_aktif_id,
						'id'=>abs(crc32(sha1(md5(rand())))),
						'jumlah'=>$cek->row('wajib_bayar'),
						'tgl_transaksi'=>$pemb->row('tgl_transaksi'),
						't_user_id'=>1,
						'penyetor'=>$pemb->row('penyetor'),
						'id_parent_jenis_pembayaran'=>10,
						'keterangan'=>7,
						'catatan'=>$pemb->row('catatan')
					);
					$this->db->insert('t_pembayaran',$ins);
				}
				// if($v->t_jenis_pembayaran_id==4)
					// echo $cek->row('id').'<br>';
			}
		}
	}
}